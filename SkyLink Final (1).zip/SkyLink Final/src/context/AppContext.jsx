import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { uid, genPNR, validatePassword, validateEmail, validatePhone, hoursUntil, fareFor } from '../lib/utils';
import { airports } from '../data/airports';

const AppCtx = createContext(null);
export const useApp = () => useContext(AppCtx);

const LS_USERS = 'skylink_users';
const LS_FLIGHTS = 'skylink_flights';
const LS_FLIGHTS_VERSION = 'skylink_flights_version';
const LS_BOOKINGS = 'skylink_bookings';
const LS_SESSION = 'skylink_session';

// Bump this whenever seedFlights()'s output shape/coverage changes.
// On load we compare it to what's stored; a mismatch (including nothing
// stored yet, e.g. from before this existed) means the cached flight list
// is from an older dataset, so we throw it away and regenerate — instead
// of silently keeping a stale, narrower flight list forever.
const FLIGHTS_SEED_VERSION = 2;

function load(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}
function save(key, value) {
  try { localStorage.setItem(key, JSON.stringify(value)); } catch { /* storage unavailable */ }
}

// Great-circle distance between two airports, in kilometers.
function distanceKm(a, b) {
  const R = 6371;
  const toRad = (v) => (v * Math.PI) / 180;
  const dLat = toRad(b.lat - a.lat);
  const dLon = toRad(b.lon - a.lon);
  const lat1 = toRad(a.lat);
  const lat2 = toRad(b.lat);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

function pad2(n) { return String(n).padStart(2, '0'); }
function fmtTime(totalMinutes) {
  const m = ((totalMinutes % 1440) + 1440) % 1440;
  return `${pad2(Math.floor(m / 60))}:${pad2(m % 60)}`;
}
function fmtDuration(mins) {
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return m ? `${h}h ${pad2(m)}m` : `${h}h`;
}

// Builds a full route network: every ordered pair of airports gets 4-5
// flights, with distance-based duration/pricing and timezone-aware arrival
// times. This is generated rather than hand-written since it covers all
// 40 airports x 39 destinations (~1,500 routes, ~7,000 flights).
function seedFlights() {
  const today = new Date();
  const d = (offset) => {
    const t = new Date(today); t.setDate(t.getDate() + offset);
    return t.toISOString().slice(0, 10);
  };

  const flights = [];
  let counter = 100;
  const dateOffsets = [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 16, 18, 20, 22, 25, 28];
  const seatLetters = ['A', 'B', 'C', 'D', 'E', 'F'];

  for (const from of airports) {
    for (const to of airports) {
      if (from.code === to.code) continue;

      const km = distanceKm(from, to);
      const avgSpeedKmh = 830;
      const durationMins = Math.round((km / avgSpeedKmh) * 60 + 35); // + taxi/climb/descent buffer
      const tzDiffMins = Math.round((to.tz - from.tz) * 60);

      // Base fare: linear per-km cost plus a long-haul surcharge so
      // international routes price up realistically while domestic
      // hops stay cheap.
      const surcharge = km > 3000 ? 8000 + (km - 3000) * 1.0 : 0;
      const baseFare = 3200 + km * 3.6 + surcharge;
      const routeJitter = 0.9 + ((from.code.charCodeAt(0) + to.code.charCodeAt(1)) % 5) * 0.05;

      const flightCount = (from.code.charCodeAt(2) + to.code.charCodeAt(0)) % 2 === 0 ? 5 : 4;

      for (let i = 0; i < flightCount; i++) {
        counter += 1;
        const departHour = (5 + i * 4 + (from.code.charCodeAt(0) % 4)) % 24;
        const departMinute = [0, 15, 30, 45][(i + to.code.charCodeAt(1)) % 4];
        const departMins = departHour * 60 + departMinute;
        const arriveMins = departMins + durationMins + tzDiffMins;

        const economyPrice = Math.round((baseFare * routeJitter * (0.94 + i * 0.03)) / 100) * 100;
        const businessMultiplier = 2.3 + ((i + from.code.charCodeAt(1)) % 6) * 0.1;
        const businessPrice = Math.round((economyPrice * businessMultiplier) / 100) * 100;

        const seatsBooked = [];
        const bookedCount = (i + from.code.charCodeAt(0) + to.code.charCodeAt(2)) % 4 === 0 ? 2 : ((i + to.code.charCodeAt(0)) % 3 === 0 ? 1 : 0);
        for (let s = 0; s < bookedCount; s++) {
          const row = 1 + ((counter + s * 3) % 9);
          const letter = seatLetters[(counter + s * 2) % seatLetters.length];
          seatsBooked.push(`${row}${letter}`);
        }

        flights.push({
          id: uid('fl'),
          flightNo: `SL ${counter}`,
          from: from.code,
          to: to.code,
          fromCity: from.city,
          toCity: to.city,
          departDate: d(dateOffsets[counter % dateOffsets.length]),
          departTime: fmtTime(departMins),
          arriveTime: fmtTime(arriveMins),
          duration: fmtDuration(durationMins),
          economyPrice,
          businessPrice,
          seatsBooked,
        });
      }
    }
  }

  return flights;
}

export function AppProvider({ children }) {
  const [users, setUsers] = useState(() => load(LS_USERS, []));
  const [flights, setFlights] = useState(() => {
    const cachedVersion = load(LS_FLIGHTS_VERSION, null);
    const cached = cachedVersion === FLIGHTS_SEED_VERSION ? load(LS_FLIGHTS, null) : null;
    return cached || seedFlights();
  });
  const [bookings, setBookings] = useState(() => load(LS_BOOKINGS, []));
  const [session, setSession] = useState(() => load(LS_SESSION, null));

  // pending booking intent stored while the auth modal interrupts a booking attempt
  const [pendingBooking, setPendingBooking] = useState(null);
  const [authModal, setAuthModal] = useState(null); // 'signin' | 'signup' | null
  const [enquiryOpen, setEnquiryOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [toast, setToast] = useState(null);

  useEffect(() => save(LS_USERS, users), [users]);
  useEffect(() => save(LS_FLIGHTS, flights), [flights]);
  useEffect(() => save(LS_FLIGHTS_VERSION, FLIGHTS_SEED_VERSION), []);
  useEffect(() => save(LS_BOOKINGS, bookings), [bookings]);
  useEffect(() => save(LS_SESSION, session), [session]);

  function notify(message, tone = 'ok') {
    setToast({ message, tone, key: uid('t') });
    window.clearTimeout(notify._t);
    notify._t = window.setTimeout(() => setToast(null), 3800);
  }

  function register({ title, firstName, lastName, email, password, confirmPassword, dob, phone }) {
    if (!firstName || !lastName) return { ok: false, message: 'Please enter your full name.' };
    if (!validateEmail(email)) return { ok: false, message: 'Please enter a valid email address.' };
    if (users.some((u) => u.email.toLowerCase() === email.toLowerCase())) {
      return { ok: false, message: 'An account with this email already exists.' };
    }
    if (!validatePhone(phone)) return { ok: false, message: 'Please enter a valid 10-digit phone number.' };
    if (!dob) return { ok: false, message: 'Please enter your date of birth.' };
    const pwCheck = validatePassword(password);
    if (!pwCheck.valid) return { ok: false, message: `Password needs ${pwCheck.errors.join(', ')}.` };
    if (password !== confirmPassword) return { ok: false, message: 'Passwords do not match.' };

    const user = { id: uid('usr'), title, firstName, lastName, email, password, dob, phone };
    setUsers((prev) => [...prev, user]);
    setSession({ type: 'user', userId: user.id }); // auto-login right after registering
    return { ok: true, user };
  }

  function login(email, password) {
    const user = users.find((u) => u.email.toLowerCase() === (email || '').toLowerCase());
    if (!user) return { ok: false, message: 'No account found with that email.' };
    if (user.password !== password) return { ok: false, message: 'Incorrect password.' };
    setSession({ type: 'user', userId: user.id });
    return { ok: true, user };
  }

  function logout() {
    setSession(null);
    setProfileOpen(false);
  }

  function resetPassword(email, newPassword, confirmPassword) {
    const user = users.find((u) => u.email.toLowerCase() === (email || '').toLowerCase());
    if (!user) return { ok: false, message: 'No account found with that email.' };
    const pwCheck = validatePassword(newPassword);
    if (!pwCheck.valid) return { ok: false, message: `Password needs ${pwCheck.errors.join(', ')}.` };
    if (newPassword !== confirmPassword) return { ok: false, message: 'Passwords do not match.' };
    setUsers((prev) => prev.map((u) => (u.id === user.id ? { ...u, password: newPassword } : u)));
    return { ok: true };
  }

  const currentUser = useMemo(() => {
    if (session?.type === 'user') return users.find((u) => u.id === session.userId) || null;
    return null;
  }, [session, users]);

  function searchFlights({ from, to }) {
    const f = (from || '').trim().toUpperCase();
    const t = (to || '').trim().toUpperCase();
    const results = flights.filter((fl) => (!f || fl.from === f) && (!t || fl.to === t));
    return results;
  }

  function seatsTaken(flightId) {
    const fl = flights.find((f) => f.id === flightId);
    return fl ? fl.seatsBooked : [];
  }

  function createBooking({ flightId, cls, seats, passengers, contact, amount }) {
    const flight = flights.find((f) => f.id === flightId);
    if (!flight) return { ok: false, message: 'Flight not found.' };
    const clash = seats.filter((s) => flight.seatsBooked.includes(s));
    if (clash.length) return { ok: false, message: `Seat(s) ${clash.join(', ')} were just taken. Please pick another seat.` };

    const pnr = genPNR();
    const booking = {
      pnr,
      id: uid('bk'),
      userId: currentUser?.id || null,
      flightId,
      cls,
      seats,
      passengers,
      contact,
      amount,
      status: 'Confirmed',
      bookedAt: new Date().toISOString(),
    };
    setFlights((prev) => prev.map((f) => (f.id === flightId ? { ...f, seatsBooked: [...f.seatsBooked, ...seats] } : f)));
    setBookings((prev) => [...prev, booking]);
    return { ok: true, booking };
  }

  function getBookingByPNR(pnr) {
    const found = bookings.find((b) => b.pnr.toUpperCase() === (pnr || '').trim().toUpperCase());
    if (!found) return { ok: false, message: 'No booking found for that PNR.' };
    const flight = flights.find((f) => f.id === found.flightId);
    return { ok: true, booking: found, flight };
  }

  function cancelBooking(bookingId) {
    const booking = bookings.find((b) => b.id === bookingId);
    if (!booking) return { ok: false, message: 'Booking not found.' };
    if (booking.status === 'Cancelled') return { ok: false, message: 'This booking is already cancelled.' };
    const flight = flights.find((f) => f.id === booking.flightId);
    const hrs = flight ? hoursUntil(flight.departDate, flight.departTime) : 999;
    if (hrs < 3) {
      return { ok: false, message: 'Cancellation is only allowed up to 3 hours before departure.' };
    }
    const deductionRate = 0.2; // 20% cancellation fee
    const refund = Math.round(booking.amount * (1 - deductionRate));
    setBookings((prev) => prev.map((b) => (b.id === bookingId ? { ...b, status: 'Cancelled', refund } : b)));
    setFlights((prev) => prev.map((f) => (f.id === booking.flightId ? { ...f, seatsBooked: f.seatsBooked.filter((s) => !booking.seats.includes(s)) } : f)));
    return { ok: true, refund };
  }

  function myBookings() {
    if (!currentUser) return [];
    return bookings.filter((b) => b.userId === currentUser.id).sort((a, b) => new Date(b.bookedAt) - new Date(a.bookedAt));
  }

  const value = {
    users, flights, bookings, session, currentUser,
    pendingBooking, setPendingBooking,
    authModal, setAuthModal,
    enquiryOpen, setEnquiryOpen,
    profileOpen, setProfileOpen,
    toast, notify,
    register, login, logout, resetPassword,
    searchFlights, seatsTaken, createBooking, getBookingByPNR, cancelBooking,
    myBookings,
    fareFor,
  };

  return <AppCtx.Provider value={value}>{children}</AppCtx.Provider>;
}
