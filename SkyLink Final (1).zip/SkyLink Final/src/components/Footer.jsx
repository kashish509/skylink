import React from 'react';
import { Plane } from 'lucide-react';
import { useApp } from '../context/AppContext';

export default function Footer() {
  const app = useApp();

  function resetDemoData() {
    const ok = window.confirm('This clears all locally saved SkyLink data (flights, bookings, and your account) and reloads the app with a fresh dataset. Continue?');
    if (!ok) return;
    try { localStorage.clear(); } catch { /* storage unavailable */ }
    window.location.reload();
  }

  return (
    <footer id="footer" className="site-footer">
      <div>
        <b className="site-footer__brand">
          <Plane size={16} className="icon-ice" /> SkyLink
        </b>
        <p className="site-footer__tagline">Fly further. Live closer.</p>
      </div>
      <small className="site-footer__copyright">
        &copy; 2026 SkyLink. All rights reserved.
        <button type="button" className="footer-reset-btn" onClick={resetDemoData}>
          Reset demo data
        </button>
      </small>
    </footer>
  );
}
