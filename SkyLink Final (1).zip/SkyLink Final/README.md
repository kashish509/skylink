# SkyLink — Premium Redesign

A cinematic, Apple-inspired redesign of the SkyLink airline booking site, built with **plain React + Vite + hand-written CSS** (no Tailwind, no Framer Motion, no other UI/animation frameworks). Core booking functionality (search, seat selection, checkout, sign in/up, PNR lookup/cancellation) is preserved. Admin login and flight-inventory management have been removed entirely — there is no admin role in the app.

## Latest pass: destination popups + dependency cleanup
- Clicking a destination photo (Tokyo, Paris, Dubai, Singapore, London, New York) now opens a popup (`src/components/DestinationModal.jsx`, data in `src/data/destinations.js`) showing the destination photo, a list of famous hotspots around that city, and a short "why choose this destination" write-up.
- Tailwind CSS and Framer Motion have been removed from the project entirely. All animation (scroll reveals, staggered entrances, modal/dropdown transitions, the search-tab underline, the expandable "Why SkyLink" cards) is now done with plain CSS `@keyframes`/transitions plus a small `useReveal` IntersectionObserver hook (`src/lib/useReveal.js`).
- The `AdminPanel` component and every related bit of admin plumbing have been deleted: no more admin login, admin credentials, "Flight Inventory" admin dashboard, or admin-only account menu items. `AppContext.jsx` no longer tracks an admin session type, and the now-unused `addFlight`/`deleteFlight` functions were removed along with it.
- `lucide-react` is kept for icons (it's a plain SVG icon library, not a styling/animation framework) — everything else is vanilla React, CSS, HTML, and JavaScript.

## Earlier pass: reachable, interactive search
- The hero is a single, fast-loading view (~85vh) with a subtle Ken Burns background animation and a fade-in headline — no scroll-linked JavaScript.
- The flight search card overlaps the bottom of the hero, so it's visible with zero or one small scroll.
- **From/To fields use a Skyscanner-style autocomplete** (`src/components/CityAutocomplete.jsx`, backed by `src/data/airports.js`): typing "D" instantly suggests Delhi, Dubai, Doha, Dublin (with country, airport name, and code), arrow keys/Enter navigate the list, and an empty field shows popular destinations.
- A whole-page scroll progress bar sits at the top of the site.
- Core flow: From → To → Dates → Travellers → Search.

## Getting started

```bash
npm install
npm run dev
```

Then open the printed local URL (typically http://localhost:5173).

To build for production:

```bash
npm run build
npm run preview
```

## Demo accounts
- Accounts are created via the **Register** tab and stored in your browser's local storage (this is a front-end demo with no backend).
